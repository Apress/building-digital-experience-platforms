package com.dxsys.integration.integratorService.model.transactionmodel;

import java.util.Collection;

public class List {
    Collection<Transaction> list;

    public Collection<Transaction> getList() {
        return list;
    }

    public void setList(Collection<Transaction> list) {
        this.list = list;
    }
}
